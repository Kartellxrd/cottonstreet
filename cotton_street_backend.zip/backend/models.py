from sqlalchemy import Column, Integer, String, Numeric, Boolean, Text, ForeignKey, TIMESTAMP
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from database import Base


class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True)
    slug = Column(String(100), nullable=False, unique=True)
    created_at = Column(TIMESTAMP, server_default=func.now())

    products = relationship("Product", back_populates="category")


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    variant = Column(String(200))
    price = Column(Numeric(10, 2), nullable=False)
    old_price = Column(Numeric(10, 2))
    badge = Column(String(50))
    category_id = Column(Integer, ForeignKey("categories.id"))
    image_url = Column(Text)
    cloudinary_id = Column(String(255))
    in_stock = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, server_default=func.now())

    category = relationship("Category", back_populates="products")


class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String(200), nullable=False)
    customer_phone = Column(String(30), nullable=False)
    customer_town = Column(String(100), nullable=False)
    items_json = Column(JSONB, nullable=False)
    total = Column(Numeric(10, 2))
    status = Column(String(30), default="pending")
    notes = Column(Text)
    created_at = Column(TIMESTAMP, server_default=func.now())


class Admin(Base):
    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), nullable=False, unique=True)
    hashed_password = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
