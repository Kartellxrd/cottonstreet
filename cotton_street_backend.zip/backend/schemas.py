from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any
from datetime import datetime
from decimal import Decimal


class CategoryBase(BaseModel):
    name: str
    slug: str


class CategoryCreate(CategoryBase):
    pass


class CategoryOut(CategoryBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class ProductBase(BaseModel):
    name: str
    variant: Optional[str] = None
    price: Decimal
    old_price: Optional[Decimal] = None
    badge: Optional[str] = None
    category_id: Optional[int] = None
    image_url: Optional[str] = None
    cloudinary_id: Optional[str] = None
    in_stock: bool = True


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    variant: Optional[str] = None
    price: Optional[Decimal] = None
    old_price: Optional[Decimal] = None
    badge: Optional[str] = None
    category_id: Optional[int] = None
    image_url: Optional[str] = None
    cloudinary_id: Optional[str] = None
    in_stock: Optional[bool] = None


class ProductOut(ProductBase):
    id: int
    created_at: datetime
    category: Optional[CategoryOut] = None

    class Config:
        from_attributes = True


class OrderCreate(BaseModel):
    customer_name: str
    customer_phone: str
    customer_town: str
    items_json: List[Any]
    total: Optional[Decimal] = None
    notes: Optional[str] = None


class OrderStatusUpdate(BaseModel):
    status: str


class OrderOut(BaseModel):
    id: int
    customer_name: str
    customer_phone: str
    customer_town: str
    items_json: List[Any]
    total: Optional[Decimal] = None
    status: str
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class AdminLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


class AdminOut(BaseModel):
    id: int
    email: str
    created_at: datetime

    class Config:
        from_attributes = True
