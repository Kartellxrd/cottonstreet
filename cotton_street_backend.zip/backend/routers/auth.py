from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import get_db
from models import Admin
from schemas import AdminLogin, Token, AdminOut
from auth import hash_password, verify_password, create_access_token, verify_token

router = APIRouter()


@router.post("/login", response_model=Token)
async def login(data: AdminLogin, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Admin).where(Admin.email == data.email))
    admin = result.scalar_one_or_none()
    if not admin or not verify_password(data.password, admin.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token({"sub": admin.email})
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me", response_model=AdminOut)
async def get_me(
    email: str = Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Admin).where(Admin.email == email))
    admin = result.scalar_one_or_none()
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    return admin


# SETUP ONLY — remove this route after creating your first admin
@router.post("/setup")
async def setup_admin(data: AdminLogin, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(Admin).where(Admin.email == data.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Admin already exists")
    admin = Admin(email=data.email, hashed_password=hash_password(data.password))
    db.add(admin)
    await db.commit()
    return {"message": f"Admin {data.email} created"}
