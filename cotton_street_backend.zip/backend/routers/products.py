from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from database import get_db
from models import Product, Category
from schemas import ProductCreate, ProductUpdate, ProductOut
from auth import verify_token
from typing import List, Optional

router = APIRouter()


@router.get("", response_model=List[ProductOut])
async def get_products(
    category: Optional[str] = Query(None),
    in_stock: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    query = select(Product).options(selectinload(Product.category))
    if in_stock is not None:
        query = query.where(Product.in_stock == in_stock)
    if category:
        query = query.join(Category).where(Category.slug == category)
    result = await db.execute(query.order_by(Product.created_at.desc()))
    return result.scalars().all()


@router.get("/{id}", response_model=ProductOut)
async def get_product(id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Product).options(selectinload(Product.category)).where(Product.id == id)
    )
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.post("", response_model=ProductOut)
async def create_product(
    data: ProductCreate,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_token),
):
    product = Product(**data.model_dump())
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return product


@router.put("/{id}", response_model=ProductOut)
async def update_product(
    id: int,
    data: ProductUpdate,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_token),
):
    result = await db.execute(select(Product).where(Product.id == id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    for key, val in data.model_dump(exclude_unset=True).items():
        setattr(product, key, val)
    await db.commit()
    await db.refresh(product)
    return product


@router.delete("/{id}")
async def delete_product(
    id: int,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_token),
):
    result = await db.execute(select(Product).where(Product.id == id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    await db.delete(product)
    await db.commit()
    return {"message": "Product deleted"}


@router.patch("/{id}/stock")
async def toggle_stock(
    id: int,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_token),
):
    result = await db.execute(select(Product).where(Product.id == id))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    product.in_stock = not product.in_stock
    await db.commit()
    return {"id": id, "in_stock": product.in_stock}
